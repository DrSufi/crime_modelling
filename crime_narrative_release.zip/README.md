# Crime Narrative Disruption Pipeline

Implements the tri modular framework from the manuscript for monthly textual entropy,
entropy weighted severity, anomaly counts via Isolation Forest, network entropy,
unsupervised regime detection, a simple pre post counterfactual for entropy with network
covariate, and a Random Forest regime forecast.

## Quick start
pip install -r requirements.txt
python -m src.run_pipeline --config config.yaml

Outputs written to outputs/

Generated on 2025-11-01T19:19:22.770628
