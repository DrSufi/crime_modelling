import argparse, json
import pandas as pd
from pathlib import Path
from .data_loader import load_config, load_data
from .entropy import monthly_textual_entropy
from .severity import monthly_entropy_weighted_severity
from .anomalies import monthly_anomaly_volume
from .network import monthly_network_entropy
from .regimes import detect_regimes
from .causal_bsts import counterfactual_entropy
from .forecast import forecast_regimes

def main(config_path: str):
    cfg = load_config(config_path)
    df = load_data(cfg)

    date_col = cfg["data"]["date_column"]
    cat_col = cfg["data"]["event_code_column"]

    ent = monthly_textual_entropy(df, date_col=date_col, category_col=cat_col)
    sev = monthly_entropy_weighted_severity(df, cfg)
    ano = monthly_anomaly_volume(df, cfg)
    net = monthly_network_entropy(df, cfg)

    sig = ent.merge(sev, on="month", how="outer").merge(ano, on="month", how="outer")
    sig = sig.sort_values("month").reset_index(drop=True)
    sig["Psi"] = sig["Psi"].interpolate().bfill().ffill()
    sig["Omega"] = sig["Omega"].fillna(0).astype(int)

    out_dir = Path("outputs")
    out_dir.mkdir(exist_ok=True, parents=True)
    sig.to_csv(out_dir / "monthly_signal.csv", index=False)

    regimes, centers = detect_regimes(sig, cfg)
    regimes.to_csv(out_dir / "regimes.csv", index=False)

    mx_label = regimes.groupby("regime")["H_text"].mean().idxmax()
    first_disrupted = regimes[regimes["regime"] == mx_label]["month"].min()
    cf = counterfactual_entropy(sig, net, intervention_month=first_disrupted)
    cf.to_csv(out_dir / "causal_effect.csv", index=False)

    report, next_regime = forecast_regimes(regimes, cfg, lags=1)
    with open(out_dir / "results.json", "w") as f:
        json.dump({"classification_report": report, "next_regime_forecast": int(next_regime)}, f, indent=2, default=str)

    import matplotlib.pyplot as plt
    plt.figure()
    plt.plot(sig["month"], sig["H_text"])
    plt.title("Monthly narrative entropy")
    plt.xlabel("Month")
    plt.ylabel("H_text")
    plt.tight_layout()
    plt.savefig(out_dir / "fig_entropy.png", dpi=160)

    plt.figure()
    plt.plot(sig["month"], sig["Psi"])
    plt.title("Entropy weighted severity")
    plt.xlabel("Month")
    plt.ylabel("Psi")
    plt.tight_layout()
    plt.savefig(out_dir / "fig_severity.png", dpi=160)

    plt.figure()
    plt.plot(sig["month"], sig["Omega"])
    plt.title("Anomaly volume")
    plt.xlabel("Month")
    plt.ylabel("Omega")
    plt.tight_layout()
    plt.savefig(out_dir / "fig_anomalies.png", dpi=160)

    print("Pipeline complete. Outputs written to ./outputs")

if __name__ == "__main__":
    import sys
    cfg_path = "config.yaml" if len(sys.argv) == 1 else sys.argv[sys.argv.index("--config")+1]
    main(cfg_path)
