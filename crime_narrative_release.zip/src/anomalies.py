import pandas as pd
import numpy as np
from sklearn.ensemble import IsolationForest
from .utils import to_month

def monthly_anomaly_volume(df, cfg):
    df = df.copy()
    date_col = cfg["data"]["date_column"]
    code_col = cfg["data"]["event_code_column"]
    country_col = cfg["data"]["country_column"]
    df["month"] = to_month(df[date_col])
    feats = (
        df.groupby("month")
          .agg(
              total_events = (code_col, "count"),
              unique_codes = (code_col, "nunique"),
              unique_countries = (country_col, "nunique")
          )
          .reset_index()
          .sort_values("month")
    )
    params = cfg["anomaly"]["isolation_forest"]
    iso = IsolationForest(
        n_estimators=params.get("n_estimators", 100),
        contamination=params.get("contamination", "auto"),
        random_state=params.get("random_state", 42),
    )
    preds = iso.fit_predict(feats[["total_events", "unique_codes", "unique_countries"]])
    feats["Omega"] = (preds == -1).astype(int)
    feats["Omega"] = feats["Omega"].rolling(window=3, min_periods=1).sum().astype(int)
    return feats[["month", "Omega"]]
