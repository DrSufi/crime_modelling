import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report

def make_lagged(df, cols, lags=1):
    out = df.copy()
    for c in cols:
        for L in range(1, lags+1):
            out[f"{c}_lag{L}"] = out[c].shift(L)
    return out.dropna().reset_index(drop=True)

def forecast_regimes(regime_df, cfg, lags=1):
    df = regime_df.sort_values("month").reset_index(drop=True)
    cols = ["H_text", "Psi", "Omega"]
    lagged = make_lagged(df, cols, lags=lags)
    if len(lagged) < 10:
        return {"warning": "insufficient data for evaluation"}, int(lagged["regime"].iloc[-1])
    X = lagged[[f"{c}_lag1" for c in cols]].to_numpy()
    y = lagged["regime"].to_numpy()
    split = int(0.8 * len(lagged))
    Xtr, Xte = X[:split], X[split:]
    ytr, yte = y[:split], y[split:]
    rf = RandomForestClassifier(
        n_estimators=cfg["forecast"]["n_estimators"],
        random_state=cfg["forecast"]["random_state"]
    )
    rf.fit(Xtr, ytr)
    yhat = rf.predict(Xte)
    try:
        report = classification_report(yte, yhat, output_dict=True)
    except Exception:
        report = {"note": "unable to compute classification report"}
    last = df.iloc[-1:][cols].to_numpy()
    next_regime = int(rf.predict(last)[0])
    return report, next_regime
