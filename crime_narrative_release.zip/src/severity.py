import pandas as pd
import numpy as np
from .utils import to_month

def monthly_entropy_weighted_severity(df, cfg):
    df = df.copy()
    date_col = cfg["data"]["date_column"]
    code_col = cfg["data"]["event_code_column"]
    sev_col = cfg["data"]["severity_column"]
    default_map = cfg["severity"]["default_code_weights"] or {}
    df["month"] = to_month(df[date_col])
    if sev_col in df.columns and pd.api.types.is_numeric_dtype(df[sev_col]):
        s = df.groupby("month")[sev_col].mean().rename("Psi")
        return s.reset_index().sort_values("month")
    df["_sev"] = df[code_col].map(default_map).fillna(5.0)
    s = df.groupby("month")["_sev"].mean().rename("Psi")
    return s.reset_index().sort_values("month")
