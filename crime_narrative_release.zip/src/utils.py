import pandas as pd
import numpy as np

def to_month(dt_series: pd.Series) -> pd.Series:
    dt = pd.to_datetime(dt_series, errors="coerce", utc=True)
    return dt.dt.to_period("M").dt.to_timestamp()

def safe_normalize(prob_like: np.ndarray) -> np.ndarray:
    total = prob_like.sum()
    if total <= 0:
        return np.zeros_like(prob_like, dtype=float)
    return prob_like / total

def shannon_entropy(prob: np.ndarray) -> float:
    prob = prob[prob > 0]
    if prob.size == 0:
        return 0.0
    return float(-(prob * np.log2(prob)).sum())
