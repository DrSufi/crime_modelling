import pandas as pd
import numpy as np
import re
from collections import Counter
from .utils import to_month, shannon_entropy

TOKEN_RE = re.compile(r"[A-Za-z]{3,}")

def tokenize(text):
    if not isinstance(text, str):
        return []
    return TOKEN_RE.findall(text.lower())

def monthly_network_entropy(df, cfg):
    df = df.copy()
    date_col = cfg["data"]["date_column"]
    title_col = cfg["data"]["title_column"]
    desc_col = cfg["data"]["description_column"]
    max_terms = cfg["network"]["max_terms"]
    df["month"] = to_month(df[date_col])
    out = []
    for m, g in df.groupby("month"):
        tokens = []
        for t in g[title_col].tolist() + g[desc_col].tolist():
            tokens.extend(tokenize(t))
        if not tokens:
            out.append({"month": m, "H_net": 0.0})
            continue
        most = [w for w,_ in Counter(tokens).most_common(max_terms)]
        idx = {w:i for i,w in enumerate(most)}
        K = len(most)
        if K == 0:
            out.append({"month": m, "H_net": 0.0})
            continue
        A = np.zeros((K, K), dtype=int)
        for t in g[title_col].tolist() + g[desc_col].tolist():
            toks = [w for w in tokenize(t) if w in idx]
            toks = list(dict.fromkeys(toks))
            for i in range(len(toks)):
                for j in range(i+1, len(toks)):
                    A[idx[toks[i]], idx[toks[j]]] += 1
                    A[idx[toks[j]], idx[toks[i]]] += 1
        Hs = []
        for i in range(K):
            row = A[i]
            s = row.sum()
            if s == 0:
                Hs.append(0.0)
            else:
                p = row / s
                Hs.append(shannon_entropy(p[p > 0]))
        H_net = float(np.mean(Hs)) if Hs else 0.0
        out.append({"month": m, "H_net": H_net})
    return pd.DataFrame(out).sort_values("month")
