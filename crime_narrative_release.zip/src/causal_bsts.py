import pandas as pd
import numpy as np
import statsmodels.api as sm

def counterfactual_entropy(signal_df, net_df, intervention_month):
    """
    Perform a simple pre post linear counterfactual for H_text with H_net as a covariate.
    """
    df = signal_df.merge(net_df, on="month", how="left")
    df = df.sort_values("month").reset_index(drop=True)
    df["post"] = (df["month"] >= pd.Timestamp(intervention_month)).astype(int)
    pre = df[df["post"] == 0]
    if pre.empty:
        split = len(df) // 2
        pre = df.iloc[:split]
    Xpre = sm.add_constant(pre[["H_net"]])
    ypre = pre["H_text"]
    model = sm.OLS(ypre, Xpre).fit()
    Xall = sm.add_constant(df[["H_net"]], has_constant="add")
    try:
        df["H_cf"] = model.predict(Xall)
    except Exception:
        df["H_cf"] = float(ypre.mean())
    df["delta"] = df["H_text"] - df["H_cf"]
    return df[["month", "H_text", "H_cf", "delta", "post"]]
