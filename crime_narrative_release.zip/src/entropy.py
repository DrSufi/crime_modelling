import pandas as pd
import numpy as np
from .utils import to_month, safe_normalize, shannon_entropy

def monthly_textual_entropy(df, date_col, category_col, rule="M"):
    df = df.copy()
    df["month"] = to_month(df[date_col])
    counts = df.groupby(["month", category_col]).size().rename("count").reset_index()
    ent = []
    for m, g in counts.groupby("month"):
        probs = safe_normalize(g["count"].to_numpy(dtype=float))
        ent.append({"month": m, "H_text": shannon_entropy(probs)})
    ent_df = pd.DataFrame(ent).sort_values("month")
    return ent_df
