import pandas as pd
import numpy as np
from sklearn.cluster import KMeans

def detect_regimes(signal_df, cfg):
    k = cfg["regimes"]["kmeans_k"]
    rs = cfg["regimes"]["random_state"]
    X = signal_df[["H_text", "Psi", "Omega"]].to_numpy()
    Xs = (X - X.mean(axis=0)) / (X.std(axis=0) + 1e-9)
    km = KMeans(n_clusters=k, random_state=rs, n_init=20)
    labels = km.fit_predict(Xs)
    out = signal_df.copy()
    out["regime"] = labels
    return out, km.cluster_centers_
